package com.music;

public class Song {
	String title;
	double duration;
	
	public Song() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Song(String title, double duration) {
		super();
		this.title = title;
		this.duration = duration;
	}

	public String getTitle() {
		return title;
	}

	public double getDuration() {
		return duration;
	}

	@Override
	public String toString() {
		return "Song [title=" + title + ", duration=" + duration + "]";
	}
	

}
