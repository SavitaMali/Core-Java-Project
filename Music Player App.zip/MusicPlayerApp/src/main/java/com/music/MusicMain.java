package com.music;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class MusicMain {
	
	private static ArrayList<Album> albums = new ArrayList<>();

	public static void main(String[] args) {
		
		Album album = new Album("Album1","Darshan Raval");
		
		album.addSong("Asal mein",3.25);
		album.addSong("Tera Zikr",3.54);
		album.addSong("Ek Tarfa",4.29);
		album.addSong("Piya Re", 3.04);
		album.addSong("Rabba Mehar Kari", 3.04);
		albums.add(album);
		
		album = new Album("Album2","Arjit Singh");
		
		album.addSong("Apna Bana Le ", 3.25);
		album.addSong("Kesariya", 2.53);
		album.addSong("Tera Fitur", 5.08);
		album.addSong("Agar Tum Sath Ho", 5.42);
		album.addSong("Hawayein", 4.52);
		
		albums.add(album);
		
		LinkedList<Song>PlayList_1 = new LinkedList<>();
		
		albums.get(0).addToPlayList("Asal mein", PlayList_1);
		albums.get(0).addToPlayList("Tera Zikr", PlayList_1);
		albums.get(1).addToPlayList("Apna Bana Le", PlayList_1);
		albums.get(1).addToPlayList("Hawayein", PlayList_1);
		albums.get(1).addToPlayList("Agar Tum Sath Ho",PlayList_1);
		
		play(PlayList_1);
	}
	private static void play(LinkedList<Song>PlayList)
	{
		Scanner sc = new Scanner(System.in);
		boolean quit = false;
		boolean forward = true;
		ListIterator<Song>listIterator = PlayList.listIterator();
		
		if(PlayList.size() == 0)
		{
			System.out.println("This PlayList have No Song");
		}
		else
		{
			System.out.println("Now Playing"+listIterator.next().toString() );
			PrintMenu();
		}
		while(!quit)
		{
			int action = sc.nextInt();
			sc.nextLine();
			
			switch (action)
			{
			case 0:
				System.out.println("PlayList Complete");
				quit = true;
				break;
				
			case 1:
				if(!forward)
				{
					if(listIterator.hasNext())
					{
						listIterator.next();
					}
					forward = true;
				}
				if(listIterator.hasNext())
				{
					System.out.println("Now Playing"+listIterator.next().toString());
				}
				else
				{
					System.out.println("No song available, reached to the end of the list");
					forward = false;
				}
				break;
				
			case 2:
				if(forward)
				{
					if(listIterator.hasPrevious())
					{
						listIterator.previous();
					}
					forward = false;
				}
				if(listIterator.hasPrevious())
				{
					System.out.println("NowPlaying"+ listIterator.previous().toString());
				}
				else
				{
					System.out.println("we are the first song");
					forward = false;
				}
				break;
				
			case 3:
				if(forward)
				{
					if(listIterator.hasPrevious())
					{
						System.out.println("NowPlaying"+ listIterator.previous().toString());
						forward = false;
					}
					else {
						System.out.println("we are at the start of the list");
					}
				}else
				{
					if(listIterator.hasNext())
					{
						System.out.println("Now Playing"+listIterator.next().toString());
						forward = true;
					}
					else
					{
						System.out.println("We have reached to the end of list");
					}
				}
				break;
				
			case 4:
				PrintList(PlayList);
				break;
				
			case 5:
				PrintMenu();
				break;
				
			case 6:
				if(PlayList.size()>0)
				{
					listIterator.remove();
					if(listIterator.hasNext())
					{
						System.out.println("Now Playing"+listIterator.next().toString());
					}
					else {
						if(listIterator.hasPrevious())
						{
							System.out.println("Now Playing"+listIterator.previous());
						}
					}
				}
			}
		}
	}
	
	private static void PrintMenu()
	{
		System.out.println("Available option\nPress");
		System.out.println("0- to quit\n"+"1 - To play next song\n"+
		                                  "2 - To play previous song\n"+
				                          "3 - To replay the current song\n"+
		                                  "4 - List of all songs\n"+
				                          "5 - Print all avilable option\n"+
		                                  "6 - Delete current song");
	}
	
	private static void PrintList(LinkedList<Song>PlayList)
	{
		Iterator<Song> iterator = PlayList.iterator();
		System.out.println("*************************************");
		
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		System.out.println("************************************");
	}

}
